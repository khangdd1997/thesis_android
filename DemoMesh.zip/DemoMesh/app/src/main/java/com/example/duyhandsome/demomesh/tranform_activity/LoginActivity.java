package com.example.duyhandsome.demomesh.tranform_activity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.duyhandsome.demomesh.MainActivity;
import com.example.duyhandsome.demomesh.R;
import com.example.duyhandsome.demomesh.androidbletutorial.Account;
import com.example.duyhandsome.demomesh.androidbletutorial.DatabaseProcess;
import com.example.duyhandsome.demomesh.devicemanagement.DeviceActivity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {
    private EditText edtuser;
    private EditText edtpassword;
    private Button btn_login;
    private Button btn_cancel;
    Account acc;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        edtuser = (EditText) findViewById(R.id.editUser);
        edtpassword = (EditText) findViewById(R.id.editPassword);
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_cancel = (Button) findViewById(R.id.btn_cancel);
        String txt_user = edtuser.getText().toString();
        String txt_password = edtuser.getText().toString();
        acc = new Account();
        acc.setUser(txt_user);
        acc.setPass(txt_password);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseProcess.username = edtuser.getText().toString();
                DatabaseProcess.password = edtpassword.getText().toString();
                accountLogin();
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent1);
            }
        });

    }

    private void accountLogin() {
        RequestQueue rq = Volley.newRequestQueue(LoginActivity.this);
        StringRequest rs = new StringRequest(Request.Method.POST, DatabaseProcess.url_login,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.trim().equals("success")) {
                            Toast.makeText(LoginActivity.this, "LOGIN SUCCESS", Toast.LENGTH_LONG).show();
                            Intent intent1 = new Intent(getApplicationContext(), DeviceActivity.class);
                            startActivity(intent1);
                        } else {
                            Toast.makeText(LoginActivity.this, "LOGIN FAILED", Toast.LENGTH_LONG).show();
                        }
                        System.out.println(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        DatabaseProcess.login_result = 0;
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("USERNAME", DatabaseProcess.username);
                params.put("PASSWORD", DatabaseProcess.password);
                return params;
            }
        };
        rq.add(rs);
    }
}