package com.example.duyhandsome.mesh.devicemanagement;

import android.app.Activity;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class AppSocketIO {

    public static Activity activity;
    public static Socket mSocket;

    static public void init(Activity act) {
        activity = act;
        try {
            mSocket = IO.socket("https://thesis-ble.herokuapp.com/");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        mSocket.on("LIGHT_STATUS", onRetriveData1);
        mSocket.on("NODE_FAILED", NodeFailedHandler);
        mSocket.connect();
    }

    private static Emitter.Listener onRetriveData1 = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int id;
                    int cmd;
                    JSONObject object = (JSONObject) args[0];
                    String data = null;
                    try {
                        data = object.getString("cmd");
                        //Toast.makeText(activity, data, Toast.LENGTH_LONG).show();
                        if(data.charAt(0) == '@') {
                            id = (data.charAt(1) - 48)*10;
                            id = data.charAt(2) - 48;
                            cmd = data.charAt(4) - 48;
                            if (cmd == 1) {
                                SwitchHandler.swNode[id - 2].setChecked(true);
                            }
                            else if (cmd == 0) {
                                SwitchHandler.swNode[id - 2].setChecked(false);
                            }
                            SwitchHandler.swNode[id - 2].setEnabled(true);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };

    private static Emitter.Listener NodeFailedHandler = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int id;
                    JSONObject object = (JSONObject) args[0];
                    String data = null;
                    try {
                        data = object.getString("nodeID");
                        id = (data.charAt(0) - 48)*10;
                        id = data.charAt(1) - 48;
                        //Toast.makeText(activity, String.format("%d", id), Toast.LENGTH_SHORT).show();
                        SwitchHandler.swNode[id].setEnabled(false);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };
}
