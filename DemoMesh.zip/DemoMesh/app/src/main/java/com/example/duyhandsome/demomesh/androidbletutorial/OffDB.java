package com.example.duyhandsome.demomesh.androidbletutorial;

import java.util.ArrayList;
import java.util.logging.Filter;

public class OffDB {
    public static ArrayList<TrainingData> offdb = new ArrayList<>();
    public static int Cur_X = 0;
    public static int Cur_Y = 0;

    public static void print() {
        for (int i = 0; i < offdb.size(); i++) {
            TrainingData t = offdb.get(i);
            System.out.println(t.toString());
        }
    }

    private static ArrayList<KNearestData> selectionSort(ArrayList<KNearestData> list) {
        ArrayList<KNearestData> sorted = list;
        for (int i = 0; i < sorted.size() - 1; i++) {
            KNearestData min = sorted.get(i);
            double min_distance = min.distance;
            int min_index = i;
            for (int j = i+1; j < sorted.size(); j++) {
                KNearestData temp = sorted.get(j);
                double temp_distance = temp.distance;
                if (min_distance > temp_distance) {
                    min_index = j;
                    min_distance = temp_distance;
                }
            }
            KNearestData swap = sorted.get(min_index);
            sorted.set(min_index, min);
            sorted.set(i, swap);
        }
        return sorted;
    }

    private static TrainingData getMinDistance(ArrayList<TrainingData> Filtered)
    {
        if (Filtered.size() != 0) {
            int paramK = 5;
            TrainingData result = new TrainingData();
            ArrayList<KNearestData> KnnData = new ArrayList<>();
            // Create Data for KNN
            for (int i = 0; i < Filtered.size(); i++) {
                TrainingData t_data = Filtered.get(i);
                for (int j = 0; j < TrainingData.NoOfRSSI; j++) {
                    KNearestData temp = new KNearestData();
                    temp.TrainingData_Index = i;
                    temp.distance = t_data.Distance[j];
                    KnnData.add(temp);
                }
            }

            KnnData = selectionSort(KnnData);
            for (int i = 0; i < KnnData.size(); i++) {
                KNearestData t = KnnData.get(i);
                System.out.println(String.format("Index: %d, Distance: %.2f", t.TrainingData_Index, t.distance));
            }
            for (int i = 0; i < paramK; i++) {
                KNearestData k = KnnData.get(i);
                TrainingData t_data = Filtered.get(k.TrainingData_Index);
                result.x += t_data.x;
                result.y += t_data.y;
            }
            result.x /= paramK;
            result.y /= paramK;
            return result;
        }
        return null;
    }

    public static TrainingData GetNearest() {
        BeaconClass b1 = TrackingProcess.BeaconList.get(0);
        BeaconClass b2 = TrackingProcess.BeaconList.get(1);

        ArrayList<TrainingData> FilteredData = filterBeaconID();

        // Calculate Distance from Unknown point to Each Rssi in Database
        System.out.println(String.format("BID %d: %d, BID %d: %d",b1.BeaconID, b1.RSSIMean, b2.BeaconID, b2.RSSIMean));
        for (int i = 0; i < FilteredData.size(); i++) {
            TrainingData t_data = FilteredData.get(i);
            double temp_distance[] = new double[TrainingData.NoOfRSSI];
            int BeaconID_Index[] = new int[2];
            // get Beacon ID index
            for (int z = 0; z < TrainingData.NoOfRSSI; z++) {
                for (int j = 0; j < 2; j++) {
                    if (b1.BeaconID == t_data.BeaconID[j]) {
                        BeaconID_Index[0] = j;
                    }
                    else if (b2.BeaconID == t_data.BeaconID[j]) {
                        BeaconID_Index[1] = j;
                    }
                }
                // Calculate Distance
                temp_distance[z] += (b1.RSSIMean - t_data.rssi[BeaconID_Index[0]][z])*(b1.RSSIMean - t_data.rssi[BeaconID_Index[0]][z]);
                temp_distance[z] += (b2.RSSIMean - t_data.rssi[BeaconID_Index[1]][z])*(b2.RSSIMean - t_data.rssi[BeaconID_Index[1]][z]);
                //System.out.println(String.format("%.2f",temp_distance[z]));
                t_data.Distance[z] = Math.sqrt(temp_distance[z]);
                //System.out.println(String.format("X:%d,Y:%d,Dis:%.2f", t_data.x, t_data.y, t_data.Distance[z]));
            }
            FilteredData.set(i, t_data);
        }

        for (int i = 0; i < FilteredData.size(); i++) {
            TrainingData t_data = FilteredData.get(i);
            for (int j = 0; j < TrainingData.NoOfRSSI; j++) {
                System.out.println(String.format("X:%d,Y:%d,Dis:%.2f", t_data.x, t_data.y, t_data.Distance[j]));
            }
        }

        TrainingData result = getMinDistance(FilteredData);
        if (result != null) {
            if (Cur_X != 0 && Cur_Y != 0) {
                if (Math.abs(result.x - Cur_X) <= 270 ) {//&& Math.abs(result.y - Cur_Y) <= 320) {
                    Cur_X = result.x;
                    Cur_Y = result.y;
                    return result;
                } else {
                    return null;
                }
            } else {
                Cur_X = result.x;
                Cur_Y = result.y;
                return result;
            }
        }
        else return null;
    }

    private static ArrayList<TrainingData> filterBeaconID() {
        ArrayList<TrainingData> filtered = new ArrayList<>();
        BeaconClass b1 = TrackingProcess.BeaconList.get(0);
        BeaconClass b2 = TrackingProcess.BeaconList.get(1);

        for (int i = 0; i < OffDB.offdb.size(); i++) {
            int correct_bid = 0;
            TrainingData t_data = OffDB.offdb.get(i);
            for (int j = 0; j < 2 /*Number of Beacon*/; j++) {
                if (b1.BeaconID == t_data.BeaconID[j]) {
                    correct_bid++;
                }
                else if (b2.BeaconID == t_data.BeaconID[j]) {
                    correct_bid++;
                }
            }
            if (correct_bid == 2) {
                filtered.add(t_data);
            }
        }

        return filtered;
    }
}

class KNearestData {
    int TrainingData_Index; // Index of TrainingData in list
    double distance;
}