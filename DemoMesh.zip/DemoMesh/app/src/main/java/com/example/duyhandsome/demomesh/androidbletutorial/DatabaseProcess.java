package com.example.duyhandsome.demomesh.androidbletutorial;
import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class DatabaseProcess {
    private Context ctx;
    public static final String url = "http://thesisble.000webhostapp.com/Tracking/GetTrainingData.php";
    public static final String url_login = "http://thesisble.000webhostapp.com/AccountLogin.php";
    public DatabaseProcess(Context context) {
        ctx = context;
    }

    public static String username = new String();
    public static String password = new String();
    public static int login_result = -1;

    public void accountLogin() {
        RequestQueue rq = Volley.newRequestQueue(ctx);
        StringRequest rs = new StringRequest(Request.Method.POST, url_login,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.trim().equals("success")) {
                            DatabaseProcess.login_result = 1;
                        }
                        else {
                            DatabaseProcess.login_result = 0;
                        }
                        System.out.println(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ctx,  error.getMessage(), Toast.LENGTH_SHORT).show();
                        DatabaseProcess.login_result = 0;
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("USERNAME", DatabaseProcess.username);
                params.put("PASSWORD", DatabaseProcess.password);
                return params;
            }
        };
        rq.add(rs);
    }

    public static String POST_dataInfo;
    public static String POST_dataRSSI;

    private boolean seachInLocation(int x, int y) {
        if (OffDB.offdb.size() == 0) {
            return false;
        }

        for (int i = 0; i < OffDB.offdb.size(); i++) {
            TrainingData temp = OffDB.offdb.get(i);
            if (x == temp.x && y == temp.y) {
                return true;
            }
        }
        return false;
    }

    public void GetData() {
        RequestQueue rq = Volley.newRequestQueue(ctx);
        JsonArrayRequest rs = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            int TrainingData_Index = -1;
                            int Current_X = -1, Current_Y = -1;
                            for (int t = 0; t < response.length(); t++) {
                                JSONObject obj = response.getJSONObject(t);
                                int x = obj.getInt("x");
                                int y = obj.getInt("y");
                                TrainingData temp;
                                JSONArray r = obj.getJSONArray("rssi");
                                // Merge TrainingData from Database
                                if (x == Current_X && y == Current_Y) {
                                    temp = OffDB.offdb.get(TrainingData_Index);
                                    temp.BeaconID[temp.BID_Index] = obj.getInt("BID");
                                    for (int i = 0; i < r.length(); i++) {
                                        temp.rssi[temp.BID_Index][i] = r.getInt(i);
                                    }
                                    temp.BID_Index++;
                                    OffDB.offdb.set(TrainingData_Index, temp);
                                }
                                else {
                                    TrainingData_Index++;
                                    temp = new TrainingData();
                                    temp.x = obj.getInt("x");
                                    temp.y = obj.getInt("y");
                                    temp.Room = obj.getString("room");
                                    temp.Floor = obj.getString("floor");
                                    temp.BeaconID[temp.BID_Index] = obj.getInt("BID");
                                    for (int i = 0; i < r.length(); i++) {
                                        temp.rssi[temp.BID_Index][i] = r.getInt(i);
                                    }
                                    temp.BID_Index++;
                                    Current_X = temp.x;
                                    Current_Y = temp.y;
                                    OffDB.offdb.add(TrainingData_Index, temp);
                                }
                                //System.out.println(TrainingData_Index);
                            }
                            for (int i = 0; i < OffDB.offdb.size(); i++) {
                                TrainingData t = OffDB.offdb.get(i);
                                for (int j = 0; j < 2; j++) {
                                    System.out.println(String.format("%d;%d;%d;%d;%d;%d", t.x, t.y, t.BeaconID[j], t.rssi[j][0], t.rssi[j][1], t.rssi[j][2]));
                                }
                            }

                            Toast.makeText(ctx, "DATABASE LOADED", Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ctx, "Loi", Toast.LENGTH_SHORT).show();
                        System.out.println(error.getMessage());
                    }
                }
        );
        rq.add(rs);
    }
}
