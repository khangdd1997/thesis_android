package com.example.duyhandsome.demomesh.devicemanagement;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.example.duyhandsome.demomesh.R;

import static android.content.Context.NOTIFICATION_SERVICE;


public class SwitchHandler {
    public Activity activity;
    public static Switch[] swNode = new Switch[5];
    public static boolean StateGetting = false;
    public static TextView temp_view;
    public static TextView flame_view;
    public static TextView[] tracking_view = new TextView[5];

    public SwitchHandler(Activity activity1) {
        activity = activity1;
        Button.OnClickListener multiListener = new View.OnClickListener() {
            public void onClick(View v) {
                int switchNum;
                int state = 0;
                switch (v.getId()) {
                    case R.id.switch1:
                        switchNum = 0;
                        state = getState(swNode[0]);
                        swNode[0].setChecked(!swNode[0].isChecked());
                        break;
                    case R.id.switch2:
                        switchNum = 1;
                        state = getState(swNode[1]);
                        swNode[1].setChecked(!swNode[1].isChecked());
                        break;
//                    case R.id.switch3:
//                        switchNum = 2;
//                        state = getState(swNode[2]);
//                        swNode[2].setChecked(!swNode[2].isChecked());
//                        break;
//                    case R.id.switch4:
//                        switchNum = 3;
//                        state = getState(swNode[3]);
//                        swNode[3].setChecked(!swNode[3].isChecked());
//                        break;
//                    case R.id.switch5:
//                        switchNum = 4;
//                        state = getState(swNode[4]);
//                        swNode[4].setChecked(!swNode[4].isChecked());
//                        break;
                    default:
                        switchNum = -1;
                        break;
                }
                if (switchNum != -1) {
                    AppSocketIO.mSocket.emit("SWITCH_CONTROL", String.format("@0%d-%d", switchNum+1, state));
                }
            }
        };
        swNode[0] = activity.findViewById(R.id.switch1);
        swNode[1] = activity.findViewById(R.id.switch2);
        //swNode[2] = activity.findViewById(R.id.switch3);
        //swNode[3] = activity.findViewById(R.id.switch4);
        //swNode[4] = activity.findViewById(R.id.switch5);
        temp_view = activity.findViewById(R.id.txt_temp);
        flame_view = activity.findViewById(R.id.txt_flame);
        tracking_view[3] = activity.findViewById(R.id.ViewTrackingStatus4);
        tracking_view[4] = activity.findViewById(R.id.ViewTrackingStatus5);
        tracking_view[0] = activity.findViewById(R.id.ViewTrackingStatus1);
        tracking_view[1] = activity.findViewById(R.id.ViewTrackingStatus2);
        tracking_view[2] = activity.findViewById(R.id.ViewTrackingStatus3);
        for (int i = 0; i < 2; i++) {
            swNode[i].setEnabled(false);
            swNode[i].setOnClickListener(multiListener);
        }
    }

    private int getState(Switch sw) {
        if (sw.isChecked() == true) {
            return 1;
        }
        else {
            return 0;
        }
    }
}
