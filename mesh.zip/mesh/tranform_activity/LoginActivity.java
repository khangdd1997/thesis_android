package com.example.duyhandsome.mesh.tranform_activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.duyhandsome.mesh.MainActivity;
import com.example.duyhandsome.mesh.R;
import com.example.duyhandsome.mesh.androidbletutorial.Account;
import com.example.duyhandsome.mesh.androidbletutorial.DatabaseProcess;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText edtuser;
    private EditText edtpassword;
    private Button btn_login;
    private Button btn_cancel;
    Account acc ;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        edtuser = (EditText)findViewById(R.id.editUser);
        edtpassword = (EditText)findViewById(R.id.editPassword);
        btn_login =(Button)findViewById(R.id.btn_login);
        btn_cancel =(Button)findViewById(R.id.btn_cancel);
        String txt_user = edtuser.getText().toString();
        String txt_password =edtuser.getText().toString();
        acc= new Account();
        acc.setUser(txt_user);
        acc.setPass(txt_password);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseProcess.username = edtuser.getText().toString();
                DatabaseProcess.password = edtpassword.getText().toString();
                DatabaseProcess t = new DatabaseProcess(LoginActivity.this);
                t.accountLogin();
                if (DatabaseProcess.login_result == 1) {
                    Toast.makeText(LoginActivity.this, "LOGIN SUCCESS", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(LoginActivity.this, "LOGIN FAILED", Toast.LENGTH_LONG).show();
                }
                DatabaseProcess.login_result = -1;
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent1);
            }
        });

    }

}
