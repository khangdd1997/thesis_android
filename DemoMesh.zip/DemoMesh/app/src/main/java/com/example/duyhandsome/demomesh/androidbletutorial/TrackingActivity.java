package com.example.duyhandsome.demomesh.androidbletutorial;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.duyhandsome.demomesh.R;
import com.example.duyhandsome.demomesh.scanner.BluetoothLeScannerCompat;
import com.example.duyhandsome.demomesh.scanner.ScanCallback;
import com.example.duyhandsome.demomesh.scanner.ScanResult;
import com.example.duyhandsome.demomesh.scanner.ScanSettings;

import java.util.ArrayList;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


public class TrackingActivity extends AppCompatActivity {

    int MapRealWidth = 1020;
    int MapRealHeigth = 2850;

    BluetoothManager btManager;
    BluetoothAdapter btAdapter;
    BluetoothLeScannerCompat btScanner;
    Button startScanningButton;
    Button stopScanningButton;
    Button btnSave;
    EditText XEdit;
    EditText YEdit;
    EditText RoomEdit;
    EditText FloorEdit;
    TextView peripheralTextView;
    TextView ResultView;
    ImageView IndoorMap;
    ArrayList<BeaconClass> BeaconList = new ArrayList<>();
    String DetectedFloor = "E06";
    private final static int REQUEST_ENABLE_BT = 1;
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    DatabaseProcess db = new DatabaseProcess(TrackingActivity.this);
    int rssi[][];
    int Cur_X = 1;
    int Cur_Y = 1;
    // INDOOR MAPPING
    ImageView button;
    DisplayMetrics displaymetrics;

    @TargetApi(Build.VERSION_CODES.M)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tracking);

        // INDOOR MAPPING
        IndoorMap = (ImageView)findViewById(R.id.background);
        button = (ImageView)findViewById(R.id.Location);
        displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);

//        peripheralTextView = (TextView) findViewById(R.id.PeripheralTextView);
//        peripheralTextView.setMovementMethod(new ScrollingMovementMethod());
        //ResultView = (TextView) findViewById(R.id.ResultView);

        startScanningButton = (Button) findViewById(R.id.StartScanButton);
        startScanningButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startScanning();
            }
        });

//        stopScanningButton = (Button) findViewById(R.id.StopScanButton);
//        stopScanningButton.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                stopScanning();
//            }
//        });

//        stopScanningButton.setVisibility(View.INVISIBLE);

        btManager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = btManager.getAdapter();
        btScanner = BluetoothLeScannerCompat.getScanner();

        if (btAdapter != null && !btAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent,REQUEST_ENABLE_BT);
        }

        // Make sure we have access coarse location enabled, if not, prompt the user to enable it
        if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("This app needs location access");
            builder.setMessage("Please grant location access so this app can detect peripherals.");
            builder.setPositiveButton(android.R.string.ok, null);
            builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onDismiss(DialogInterface dialog) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST_COARSE_LOCATION);
                }
            });
            builder.show();
        }

        db.GetData();
        //db.GetData();
    }

    // Device scan callback.
    private ScanCallback leScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
        if (TrackingProcess.SCANNING == true) {
            BeaconClass beacon = TrackingProcess.ResultProcess(result);
            if (beacon != null) {
                if (result.getRssi() > -95) {
                    TrackingProcess.SCANNING = false;
                }
                //peripheralTextView.append(beacon.RSSICount+". "+beacon.BeaconName + " ID: "+beacon.BeaconID + " RAW: " + result.getRssi() + " Filtered:" + beacon.Cur_RSSI+ "\n");

                    if (TrackingProcess.checkCondition() == true) {
                        TrackingProcess.SCANNING = false;
                        rssi = new int[TrackingProcess.BeaconCount][2];
                        int mean = 0;
                        BeaconClass t[] = new BeaconClass[TrackingProcess.BeaconCount];
                        for (int i = 0; i < TrackingProcess.BeaconCount; i++) {
                            t[i] = TrackingProcess.BeaconList.get(i);
                            for (int j = 0; j < t[i].RSSI.size(); j++) {
                                mean += t[i].RSSI.get(j);
                            }
                            mean /= t[i].RSSI.size();
                            t[i].RSSIMean = mean;
                            TrackingProcess.BeaconList.remove(i);
                            TrackingProcess.BeaconList.add(i, t[i]);
                        }
                        //stopScanning();
                        //resultPrint();
                        TrainingData t_data = OffDB.GetNearest();
                        //ResultView.setText(t_data.Room + ";"+t_data.Floor+";"+t_data.x+";"+t_data.y);
                        //System.out.println(t_data.x + " ; " + t_data.y);
                        int XConvert;
                        int YConvert;
                        if (t_data != null) {
                            XConvert = IndoorMap.getWidth() * t_data.x / MapRealWidth;
                            YConvert = IndoorMap.getHeight() * t_data.y / MapRealHeigth;
                            Cur_X = XConvert;
                            Cur_Y = YConvert;
                        }
                        else {
                            XConvert = Cur_X;
                            YConvert = Cur_Y;
                        }
                        button.animate()
                                .x(XConvert)
                                .y(YConvert)
                                .setDuration(0)
                                .start();

                        TrackingProcess.BeaconCount = 0;
                        TrackingProcess.reset();
                        try {
                            TimeUnit.MILLISECONDS.sleep(100);
                        } catch (InterruptedException ex) {

                        }

                    }
                TrackingProcess.SCANNING = true;
                // auto scroll for text view
                //final int scrollAmount = peripheralTextView.getLayout().getLineTop(peripheralTextView.getLineCount()) - peripheralTextView.getHeight();
                // if there is no need to scroll, scrollAmount will be <=0
                //if (scrollAmount > 0)
                    //peripheralTextView.scrollTo(0, scrollAmount);
            }
        }
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("coarse location permission granted");
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Functionality limited");
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons when in the background.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                        @Override
                        public void onDismiss(DialogInterface dialog) {
                        }

                    });
                    builder.show();
                }
                return;
            }
        }
    }

    public void startScanning() {
        //System.out.println("start scanning");
        //peripheralTextView.setText("");
        startScanningButton.setEnabled(false);
        startScanningButton.setVisibility(View.INVISIBLE);
        //stopScanningButton.setVisibility(View.VISIBLE);
        try {
            TimeUnit.MILLISECONDS.sleep(50);
        } catch (InterruptedException ex) {

        }
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                ScanSettings scanSettings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                        .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
                        .setNumOfMatches(ScanSettings.MATCH_NUM_ONE_ADVERTISEMENT)
                        .setReportDelay(0L)
                        .build();
                btScanner.startScan(null, scanSettings, leScanCallback);
            }
        });
    }

    public void stopScanning() {
        System.out.println("stopping scanning");
        peripheralTextView.append("Stopped Scanning");
        startScanningButton.setEnabled(true);
        //startScanningButton.setVisibility(View.VISIBLE);
        //stopScanningButton.setVisibility(View.INVISIBLE);
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                btScanner.stopScan(leScanCallback);
            }
        });
    }

    public void resultPrint() {
        rssi = new int[2][11];
        //peripheralTextView.append("\n");
        BeaconClass t[] = new BeaconClass[2];
        t[0] = TrackingProcess.BeaconList.get(0);
        t[1] = TrackingProcess.BeaconList.get(1);
        if (t[0].BeaconID > t[1].BeaconID) {
            BeaconClass temp = t[0];
            t[0] = t[1];
            t[1] = temp;
        }
        for (int i = 0; i < 2; i++) {
            //peripheralTextView.append(t[i].BeaconName+": ");
            rssi[i][0] = t[i].BeaconID;
            for (int j = 40; j < 50; j++) {
                //peripheralTextView.append(t[i].RSSI.get(j).toString()+ "; ");
                rssi[i][j-39] = t[i].RSSI.get(j);
            }
            //peripheralTextView.append("\n");
        }

//        rssi = new int[TrackingProcess.BeaconCount][2];
//        int mean = 0;
//        peripheralTextView.append("\n");
//        BeaconClass t[] = new BeaconClass[TrackingProcess.BeaconCount];
//        for (int i = 0; i < TrackingProcess.BeaconCount; i++) {
//            t[i] = TrackingProcess.BeaconList.get(i);
//            peripheralTextView.append(t[i].BeaconName+": ");
//            for (int j = 0; j < t[i].RSSI.size(); j++) {
//                mean += t[i].RSSI.get(j);
//            }
//            mean /= t[i].RSSI.size();
//            rssi[i][0] = t[i].BeaconID;
//            rssi[i][1] = mean;
//            peripheralTextView.append(String.format("%d",mean));
//            peripheralTextView.append("\n");
//        }
    }
}
