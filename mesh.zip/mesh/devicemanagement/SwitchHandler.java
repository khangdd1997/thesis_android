package com.example.duyhandsome.mesh.devicemanagement;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

import com.example.duyhandsome.mesh.R;


public class SwitchHandler {
    public Activity activity;
    public static Switch[] swNode = new Switch[5];
    public static boolean StateGetting = false;

    public SwitchHandler(Activity activity1) {
        activity = activity1;
        Button.OnClickListener multiListener = new View.OnClickListener() {
            public void onClick(View v) {
                int switchNum;
                int state = 0;
                switch (v.getId()) {
                    case R.id.switch1_id:
                        switchNum = 0;
                        state = getState(swNode[0]);
                        swNode[0].setChecked(!swNode[0].isChecked());
                        break;
                    case R.id.switch2_id:
                        switchNum = 1;
                        state = getState(swNode[1]);
                        swNode[1].setChecked(!swNode[1].isChecked());
                        break;
                    case R.id.switch3_id:
                        switchNum = 2;
                        state = getState(swNode[2]);
                        swNode[2].setChecked(!swNode[2].isChecked());
                        break;
                    case R.id.switch4_id:
                        switchNum = 3;
                        state = getState(swNode[3]);
                        swNode[3].setChecked(!swNode[3].isChecked());
                        break;
                    case R.id.switch5_id:
                        switchNum = 4;
                        state = getState(swNode[4]);
                        swNode[4].setChecked(!swNode[4].isChecked());
                        break;
                    default:
                        switchNum = -1;
                        break;
                }
                if (switchNum != -1) {
                    AppSocketIO.mSocket.emit("LIGHT_CONTROL", String.format("@0%d-%d", switchNum+2, state));
                }
            }
        };
        swNode[0] = activity.findViewById(R.id.switch1_id);
        swNode[1] = activity.findViewById(R.id.switch2_id);
        swNode[2] = activity.findViewById(R.id.switch3_id);
        swNode[3] = activity.findViewById(R.id.switch4_id);
        swNode[4] = activity.findViewById(R.id.switch5_id);
        for (int i = 0; i < swNode.length; i++) {
            swNode[i].setEnabled(false);
            swNode[i].setOnClickListener(multiListener);
        }
    }

    private int getState(Switch sw) {
        if (sw.isChecked() == true) {
            return 1;
        }
        else {
            return 0;
        }
    }
}
