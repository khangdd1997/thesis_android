package com.example.duyhandsome.demomesh;


import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.duyhandsome.demomesh.androidbletutorial.TrackingActivity;
import com.example.duyhandsome.demomesh.tranform_activity.LoginActivity;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btn_emp ;
    private Button btn_guest1 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BluetoothAdapter bAdapter = BluetoothAdapter.getDefaultAdapter();
        if(bAdapter==null){
            Toast toast=Toast.makeText(MainActivity.this, "Thiết bị không hỗ trợ Bluetooth",   Toast.LENGTH_SHORT);
            toast.show();
        }
        else {
            if (!bAdapter.isEnabled()) {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 1);
                chooseMode();
            }
            else{
                chooseMode();
            }
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }
    /*choose employee or guest*/
    public void chooseMode(){
        btn_emp = (Button)findViewById(R.id.btn_employee);
        btn_guest1 = (Button)findViewById(R.id.btn_guest);
        btn_emp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intent1);
            }
        });
        btn_guest1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(MainActivity.this,TrackingActivity.class);
                startActivity(intent2);
            }
        });
    }
}
