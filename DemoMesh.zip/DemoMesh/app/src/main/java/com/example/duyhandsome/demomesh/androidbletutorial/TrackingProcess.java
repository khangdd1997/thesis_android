package com.example.duyhandsome.demomesh.androidbletutorial;

import com.example.duyhandsome.demomesh.scanner.ScanResult;

import java.util.ArrayList;

public class TrackingProcess {
    public static int BeaconCount = 0;
    private static int RSSICount;
    private static String DetectedFloor = "E06";
    public static ArrayList<BeaconClass> BeaconList = new ArrayList<>();
    public static ArrayList<Float> FilteredRSSI = new ArrayList<>();
    public static boolean SCANNING = true;

    public static BeaconClass ResultProcess(ScanResult result) {
        String device_name =  result.getDevice().getName();
        if (device_name != null) {
            if (device_name.length() > 8) {
                String prefix = device_name.substring(0, 8);
                if (prefix.equals("TRACKING")) {
                    String floor = device_name.substring(9,12);
                    //if (floor.equals(DetectedFloor)) {
                        // Get Beacon id
                        int id = Integer.parseInt(device_name.substring(13,14));
                        int status = BeaconClass.findInBeaconList(BeaconList, device_name);
                        int returnval;
                        // If no Beacon found in list
                        if (status == -1) {
                            if (BeaconCount < 3) {
                                if (result.getRssi() > -97) {
                                    BeaconClass t = new BeaconClass();
                                    returnval = result.getRssi();
                                    t.BeaconName = device_name;
                                    returnval = t.filter.FilterSingle(result.getRssi());
                                    t.Cur_RSSI = returnval;
                                    t.RSSI.add(returnval);
                                    t.RSSICount++;
                                    t.BeaconID = id;
                                    BeaconList.add(t);
                                    BeaconCount++;
                                    return t;
                                }
                            }
                        }
                        else {
                            if (result.getRssi() > -95) {
                                BeaconClass t = BeaconList.get(status);
                                if (t.RSSIFull == false) {
                                    returnval = result.getRssi();
                                    returnval = t.filter.FilterSingle(result.getRssi());
                                    t.Cur_RSSI = returnval;
                                    t.RSSI.add(returnval);
                                    t.RSSICount++;
                                    if (t.RSSICount >= 25) {
                                        t.filter.resetFilter();
                                        t.RSSIFull = true;
                                    }
                                    BeaconList.remove(status);
                                    BeaconList.add(status, t);
                                    return t;
                                }
                            }
                            else {
                                BeaconClass t = BeaconList.get(status);
                                BeaconList.remove(status);
                                BeaconList.trimToSize();
                                BeaconCount--;
                                return t;
                            }
                        }
                        // For debug: return null;
                    //}
                }
            }
        }
        return null;
    }

    public static void reset() {
        BeaconList.removeAll(BeaconList);
    }
    public static boolean checkCondition() {
        if (BeaconCount > 1) {
            BeaconClass t1 = BeaconList.get(0);
            BeaconClass t2 = BeaconList.get(1);
            BeaconClass t3;
            int rssi_full = 0;

            for (int i = 0; i < BeaconList.size(); i++) {
                BeaconClass t = BeaconList.get(i);
                if (t.RSSIFull == true) {
                    rssi_full++;
                }
            }
            if (rssi_full == BeaconList.size()) {
                return true;
            }
        }
        return false;
    }
}
