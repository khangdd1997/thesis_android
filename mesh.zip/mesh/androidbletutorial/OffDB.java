package com.example.duyhandsome.mesh.androidbletutorial;

import java.util.ArrayList;

public class OffDB {
    public static ArrayList<TrainingData> offdb = new ArrayList<>();

    public static void print() {
        for (int i = 0; i < offdb.size(); i++) {
            TrainingData t = offdb.get(i);
            System.out.println(t.toString());
        }
    }

    private static int getMinDistance()
    {
        Location temp = Location.list.get(0);
        int index = 0;
        int i;
        float min = temp.distance;
        for (i = 1; i < Location.list.size(); i++) {
            //System.out.println(temp.x+":"+temp.y+":"+temp.distance);
            Location temp1 = Location.list.get(i);
            if (min > temp1.distance) {
                min = temp1.distance;
                index = i;
            }
        }
        return index;
    }

    public static TrainingData GetNearest() {
        ArrayList<TrainingData> filtered = searchOffDB();
        int index;
        BeaconClass b1 = TrackingProcess.BeaconList.get(0);
        BeaconClass b2 = TrackingProcess.BeaconList.get(1);
        BeaconClass b3 = null;
        ArrayList<Integer> rssi1,rssi2,rssi3;
        rssi1 = b1.RSSI;
        rssi2 = b2.RSSI;
        if (TrackingProcess.BeaconCount == 3) {
            b3 = TrackingProcess.BeaconList.get(2);
            rssi3 = b3.RSSI;
        }
        ArrayList<Float> distance = new ArrayList<>();
        for (int i = 0; i < filtered.size(); i++) {
            TrainingData t_data = filtered.get(i);

                if (b1.BeaconID == t_data.BeaconID) {
                    t_data.Distance = distanceCal(b1.RSSI, t_data.rssi);
                }
                else if (b2.BeaconID == t_data.BeaconID) {
                    t_data.Distance = distanceCal(b2.RSSI, t_data.rssi);
                }
                else if (TrackingProcess.BeaconCount == 3) {
                    if (b3.BeaconID == t_data.BeaconID) {
                        t_data.Distance = distanceCal(b3.RSSI, t_data.rssi);
                    }
                }
                filtered.remove(i);
                filtered.add(i,t_data);
        }

        for (int i = 0; i < Location.list.size(); i++) {
            Location temp = Location.list.get(i);
            for (int j = 0; j < filtered.size(); j++) {
                TrainingData t_data = filtered.get(j);
                if (temp.x == t_data.x && temp.y == t_data.y) {
                    temp.distance += t_data.Distance;
                    Location.list.remove(i);
                    Location.list.add(i, temp);
                }
            }
        }

        Location t = Location.list.get(getMinDistance());
        for (int i = 0; i < filtered.size(); i++) {
            TrainingData t_data = filtered.get(i);
            if (t.x == t_data.x && t.y == t_data.y) {
                Location.reset();
                return t_data;
            }
        }
        Location.reset();
        return null;
    }

    private static ArrayList<TrainingData> searchOffDB() {
        ArrayList<TrainingData> filtered = new ArrayList<>();
        BeaconClass b1 = TrackingProcess.BeaconList.get(0);
        BeaconClass b2 = TrackingProcess.BeaconList.get(1);
        BeaconClass b3 = null;
        String floor1 = b1.BeaconName.substring(9,12);
        String floor2 = b2.BeaconName.substring(9,12);
        String floor3 = "";
        boolean filtered_flag = false;

        if (TrackingProcess.BeaconCount == 3) {
            b3 = TrackingProcess.BeaconList.get(2);
            floor3 = b3.BeaconName.substring(9,12);
        }

        for (int j = 0; j < offdb.size(); j++) {
            TrainingData cmp = offdb.get(j);
            if (b1.BeaconID == cmp.BeaconID && floor1.equals(cmp.Floor)) {
                filtered.add(cmp);
                filtered_flag = true;
            }
            else if (b2.BeaconID == cmp.BeaconID && floor2.equals(cmp.Floor)) {
                filtered.add(cmp);
                filtered_flag = true;
            }
            else if (TrackingProcess.BeaconCount == 3) {
                if (b3.BeaconID == cmp.BeaconID && floor3.equals(cmp.Floor)) {
                    filtered.add(cmp);
                    filtered_flag = true;
                }
            }
            if (filtered_flag == true) {
                if (Location.searchInLocation(cmp.x, cmp.y) == false) {
                    Location temp = new Location(cmp.x, cmp.y);
                    Location.list.add(temp);
                }
                filtered_flag = false;
            }
        }
        return filtered;
    }

    private static float distanceCal(ArrayList<Integer> rssiInput, int rssi2[]) {
        float dis = 0;
        int rssi1;
        for (int i = 0; i < 10; i++) {
            rssi1 = rssiInput.get(i);
            dis += (rssi1 - rssi2[i])*(rssi1 - rssi2[i]);
        }
        dis = (float)Math.sqrt(dis);
        return dis;
    }
}

class Location {
    public int x;
    public int y;
    public float distance = 0;

    public Location(int X, int Y) {
        x = X;
        y = Y;
    }

    public static ArrayList<Location> list = new ArrayList<>();
    public static boolean searchInLocation(int x, int y) {
        if (Location.list.size() == 0) {
            return false;
        }
        for (int i = 0; i < Location.list.size(); i++) {
            Location t = Location.list.get(i);
            if (t.x == x && t.y == y) {
                return true;
            }
        }
        return false;
    }
    public static void reset() {
        list.removeAll(list);
    }
}