package com.example.duyhandsome.demomesh.devicemanagement;

import android.app.Activity;
import android.graphics.Color;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

import static java.lang.Integer.parseInt;

public class AppSocketIO {

    public static Activity activity;
    public static Socket mSocket;

    static public void init(Activity act) {
        activity = act;
        try {
            mSocket = IO.socket("https://thesis-ble.herokuapp.com/");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        mSocket.on("SWITCH_STATUS", SwitchStatusHandler);
        mSocket.on("SENSOR_UPDATE", SensorUpdateHandler);
        mSocket.on("NODE_STATUS", NodeStatusHandler);
        mSocket.on("NODE_FAILED", NodeFailedHandler);
        mSocket.connect();
    }

    private static Emitter.Listener SwitchStatusHandler = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int id;
                    int value;
                    JSONObject object = (JSONObject) args[0];
                    try {
                        id = parseInt(object.getString("nodeID")) - 1;
                        value = parseInt(object.getString("value"));
                        //Toast.makeText(activity, data, Toast.LENGTH_LONG).show();
                        if (value == 1) {
                            SwitchHandler.swNode[id].setChecked(true);
                        }
                        else if (value == 0) {
                            SwitchHandler.swNode[id].setChecked(false);
                        }
                        SwitchHandler.swNode[id].setEnabled(true);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };

    private static Emitter.Listener SensorUpdateHandler = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int id;
                    int value;
                    JSONObject object = (JSONObject) args[0];
                    try {
                        id = parseInt(object.getString("nodeID"));
                        value = parseInt(object.getString("value"));
                        //Toast.makeText(activity, String.format("%d", id), Toast.LENGTH_SHORT).show();
                        switch (id) {
                            case 0:
                                SwitchHandler.temp_view.setTextColor(Color.GREEN);
                                SwitchHandler.temp_view.setText(String.format("%d" + "\u2103", value));
                                break;
                            case 1:
                                if (value == 0) {
                                    SwitchHandler.flame_view.setTextColor(Color.GREEN);
                                    SwitchHandler.flame_view.setText("SAFE");
                                }
                                else {
                                    SwitchHandler.flame_view.setTextColor(Color.parseColor("#FFA500"));
                                    SwitchHandler.flame_view.setText("FIRE");
                                    NotificationHelper noti = new NotificationHelper(activity);
                                    noti.createNotification("FIRE!!!", "THERE IS FIRE !!!");
                                }
                                break;
                            default:
                                break;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };

    private static Emitter.Listener NodeStatusHandler = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int id;
                    int value;
                    JSONObject object = (JSONObject) args[0];
                    try {
                        id = parseInt(object.getString("nodeID"));
                        value = parseInt(object.getString("value"));
                        //Toast.makeText(activity, String.format("%d", id), Toast.LENGTH_SHORT).show();
                        switch (id) {
                            case 3:
                                SwitchHandler.tracking_view[3].setTextColor(Color.GREEN);
                                SwitchHandler.tracking_view[3].setText("OK");
                                break;
                            case 4:
                                SwitchHandler.tracking_view[4].setTextColor(Color.GREEN);
                                SwitchHandler.tracking_view[4].setText("OK");
                                break;
                            case 5:
                                SwitchHandler.tracking_view[0].setTextColor(Color.GREEN);
                                SwitchHandler.tracking_view[0].setText("OK");
                                break;
                            case 6:
                                SwitchHandler.tracking_view[1].setTextColor(Color.GREEN);
                                SwitchHandler.tracking_view[1].setText("OK");
                                if (value == 0) {
                                    SwitchHandler.flame_view.setTextColor(Color.GREEN);
                                    SwitchHandler.flame_view.setText("SAFE");
                                }
                                else {
                                    SwitchHandler.flame_view.setTextColor(Color.parseColor("#FFA500"));
                                    SwitchHandler.flame_view.setText("FIRE");
                                    NotificationHelper noti = new NotificationHelper(activity);
                                    noti.createNotification("FIRE!!!", "THERE IS FIRE !!!");
                                }
                                break;
                            case 7:
                                SwitchHandler.tracking_view[2].setTextColor(Color.GREEN);
                                SwitchHandler.tracking_view[2].setText("OK");
                                break;
                            default:
                                break;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };

    private static Emitter.Listener NodeFailedHandler = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int id;
                    JSONObject object = (JSONObject) args[0];
                    try {
                        id = parseInt(object.getString("nodeID"));
                        //Toast.makeText(activity, String.format("%d", id), Toast.LENGTH_SHORT).show();
                        if (id == 0) {
                            SwitchHandler.temp_view.setTextColor(Color.RED);
                            SwitchHandler.temp_view.setText("NA");
                        }
                        else if (id >= 3 && id <= 8) {
                            switch (id) {
                                case 3:
                                    SwitchHandler.tracking_view[3].setTextColor(Color.RED);
                                    SwitchHandler.tracking_view[3].setText("NA");
                                    break;
                                case 4:
                                    SwitchHandler.tracking_view[4].setTextColor(Color.RED);
                                    SwitchHandler.tracking_view[4].setText("NA");
                                    break;
                                case 5:
                                    SwitchHandler.tracking_view[0].setTextColor(Color.RED);
                                    SwitchHandler.tracking_view[0].setText("NA");
                                    break;
                                case 6:
                                    SwitchHandler.tracking_view[1].setTextColor(Color.RED);
                                    SwitchHandler.tracking_view[1].setText("NA");
                                    SwitchHandler.flame_view.setTextColor(Color.RED);
                                    SwitchHandler.flame_view.setText("NA");
                                    break;
                                case 7:
                                    SwitchHandler.tracking_view[2].setTextColor(Color.RED);
                                    SwitchHandler.tracking_view[2].setText("NA");
                                    break;
                                default:
                                    break;
                            }
                        }
                        else {
                            SwitchHandler.swNode[id - 1].setEnabled(false);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };
}
