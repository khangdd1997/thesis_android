package com.example.duyhandsome.mesh.androidbletutorial;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class DatabaseProcess {
    private Context ctx;
    private final String url = "http://thesisble.000webhostapp.com/Tracking/GetTrainingData.php";
    private final String url_login = "http://thesisble.000webhostapp.com/AccountLogin.php";
    public DatabaseProcess(Context context) {
        ctx = context;
    }

    public static String username = new String();
    public static String password = new String();
    public static int login_result = -1;

    public void accountLogin() {
        RequestQueue rq = Volley.newRequestQueue(ctx);
        StringRequest rs = new StringRequest(Request.Method.POST, url_login,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.trim().equals("success")) {
                            DatabaseProcess.login_result = 1;
                        }
                        else {
                            DatabaseProcess.login_result = 0;
                        }
                        System.out.println(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ctx,  error.getMessage(), Toast.LENGTH_SHORT).show();
                        DatabaseProcess.login_result = 0;
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("USERNAME", DatabaseProcess.username);
                params.put("PASSWORD", DatabaseProcess.password);
                return params;
            }
        };
        rq.add(rs);
    }

    public static String POST_dataInfo;
    public static String POST_dataRSSI;

    public void GetData() {
        RequestQueue rq = Volley.newRequestQueue(ctx);
        JsonArrayRequest rs = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(ctx, "DATABASE LOADED", Toast.LENGTH_LONG).show();
                        try {
                            for (int t = 0; t < response.length(); t++) {
                                JSONObject obj = response.getJSONObject(t);
                                TrainingData temp = new TrainingData();
                                temp.x = obj.getInt("x");
                                temp.y = obj.getInt("y");
                                temp.Room = obj.getString("room");
                                temp.Floor = obj.getString("floor");
                                temp.BeaconID = obj.getInt("BID");
                                JSONArray r = obj.getJSONArray("rssi");
                                for (int i = 0; i < 10; i++) {
                                    temp.rssi[i] = r.getInt(i);
                                }
                                OffDB.offdb.add(temp);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ctx, "Loi", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        rq.add(rs);
    }
}
