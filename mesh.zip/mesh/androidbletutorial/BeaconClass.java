package com.example.duyhandsome.mesh.androidbletutorial;

import java.util.ArrayList;

public class BeaconClass {
    public ArrayList<Integer> RSSI = new ArrayList<>();
    public int Cur_RSSI= 0;
    public int RSSICount = 0;
    public String BeaconName;
    public int BeaconID;
    public KalmanFilter filter = new KalmanFilter();
    public boolean RSSIFull = false;

    public static int findInBeaconList(ArrayList<BeaconClass> list, String name) {
        if (list.size() == 0) {
            return -1;
        }
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).BeaconName.equals(name)) {
                return i;
            }
        }
        return -1;
    }
}
