package com.example.duyhandsome.demomesh.devicemanagement;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.duyhandsome.demomesh.MainActivity;
import com.example.duyhandsome.demomesh.R;
import com.example.duyhandsome.demomesh.tranform_activity.LoginActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;


public class DeviceActivity extends AppCompatActivity {

    public static Activity activity;
    NotificationHelper noti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.control_devices);

        noti = new NotificationHelper(this);
        AppSocketIO.init(this);
        SwitchHandler sw = new SwitchHandler(this);
    }
}
