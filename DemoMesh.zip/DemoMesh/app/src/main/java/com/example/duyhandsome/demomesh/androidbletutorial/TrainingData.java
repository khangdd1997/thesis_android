package com.example.duyhandsome.demomesh.androidbletutorial;

public class TrainingData {
    public int x;
    public int y;
    public String Room;
    public String Floor;
    int BeaconID[] = new int[2];
    int rssi[][] = new int[2][NoOfRSSI];
    int vote;
    double Distance[] = new double[NoOfRSSI];
    int BID_Index = 0;

    public static int NoOfRSSI = 5;
}
