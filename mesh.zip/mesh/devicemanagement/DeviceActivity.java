package com.example.duyhandsome.mesh.devicemanagement;

import android.os.Bundle;

import com.example.duyhandsome.mesh.R;

import androidx.appcompat.app.AppCompatActivity;

public class DeviceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        AppSocketIO.init(this);
        SwitchHandler sw = new SwitchHandler(this);
    }
}
