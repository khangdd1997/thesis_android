package com.example.duyhandsome.mesh.androidbletutorial;

import java.util.ArrayList;

public class KalmanFilter {
    private float Kgain = 0;
    private float Pk = 1;
    private float noise = (float)0.0005;
    private float PreRSSI = 0;

    public ArrayList<Float> Filter(ArrayList<Integer> input) {
        ArrayList<Float> output = new ArrayList<Float>();
        float Cur_Xk, Pre_Xk;

        Kgain = Pk/(Pk + noise);
        Pre_Xk = Kgain*(input.get(0) - 0);
        Pk = (1 - Kgain)*Pk;
        output.add(Pre_Xk);

        for (int i = 1; i < input.size(); i++) {
            Kgain = Pk/(Pk+noise);
            Cur_Xk = Pre_Xk + Kgain*(input.get(i) - Pre_Xk);
            Pk = (1 - Kgain)*Pk;
            Pre_Xk = Cur_Xk;

            output.add(Pre_Xk);
        }
        Pk = 1;
        Kgain = 0;
        return output;
    }

    public int FilterSingle(int RSSI) {
        float Cur_Xk = RSSI, Pre_Xk = PreRSSI;

        Kgain = Pk/(Pk + noise);
        Cur_Xk = Pre_Xk + Kgain*(Cur_Xk - Pre_Xk);
        Pk = (1 - Kgain)*Pk;
        PreRSSI = Cur_Xk;

        return (int)Cur_Xk;
    }

    public void resetFilter() {
        Kgain = 0;
        Pk = 1;
        PreRSSI = 0;
    }
}

