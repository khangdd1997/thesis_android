package com.example.duyhandsome.mesh.androidbletutorial;

public class TrainingData {
    public int x;
    public int y;
    public String Room;
    public String Floor;
    public int BeaconID;
    public int rssi[] = new int[10];
    public float Distance;
    public int Index;

}
